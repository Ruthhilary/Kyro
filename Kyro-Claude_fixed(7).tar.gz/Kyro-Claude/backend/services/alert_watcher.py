"""
Kyro — Alert Watcher

Background task that watches Redis health keys for all registered cameras
every 10 seconds and fires Web Push notifications when:
  - Occupancy crosses warn/critical thresholds (debounced — only fires once per crossing)
  - A camera that was running goes offline

State is kept in-process (dict). Debounce resets when occupancy drops below threshold.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Optional

import redis
from sqlalchemy import select

logger = logging.getLogger(__name__)

POLL_INTERVAL = 10  # seconds between checks

_redis = redis.Redis(
    host=os.environ.get("REDIS_HOST", "localhost"),
    port=int(os.environ.get("REDIS_PORT", "6379")),
    decode_responses=True,
)


@dataclass
class _ZoneState:
    """Debounce state per camera."""
    last_warn_fired:  bool = False
    last_crit_fired:  bool = False
    was_running:      bool = False


_zone_states: dict[str, _ZoneState] = {}


def _get_live_count(camera_id: str) -> Optional[tuple[int, int, bool]]:
    """
    Returns (current, capacity, is_running) from Redis health key.
    Returns None if key missing.
    """
    raw = _redis.get(f"kyro:health:{camera_id}")
    if not raw:
        return None
    try:
        data = json.loads(raw)
        current  = int(data.get("current", 0))
        capacity = int(data.get("capacity", 0))
        return current, capacity, True
    except Exception:
        return None


async def _fire_push_for_zone(
    camera_id: str,
    zone_name: str,
    current: int,
    capacity: int,
    pct: float,
    level: str,  # "warning" | "critical" | "offline"
) -> None:
    """Look up all active rules matching this camera and fire pushes."""
    try:
        from backend.database.connection import AsyncSessionLocal
        from backend.database.push_models import PushSubscription, NotificationRule
        from backend.services.push_sender import send_push

        title = {
            "warning":  f"⚠️  {zone_name} filling up",
            "critical": f"🚨 {zone_name} — overcrowded!",
            "offline":  f"📵 {zone_name} camera offline",
        }.get(level, "Kyro Alert")

        body = {
            "warning":  f"{current} people · {int(pct)}% of {capacity} seats",
            "critical": f"Only {max(0, capacity - current)} seats left · {int(pct)}% full",
            "offline":  "Camera stopped sending data.",
        }.get(level, "")

        payload = {
            "title":     title,
            "body":      body,
            "tag":       f"kyro-{camera_id}-{level}",
            "camera_id": camera_id,
            "level":     level,
            "pct":       round(pct, 1),
        }

        async with AsyncSessionLocal() as db:
            # Find all rules that cover this camera
            result = await db.execute(
                select(NotificationRule, PushSubscription)
                .join(PushSubscription, NotificationRule.subscription_id == PushSubscription.id)
                .where(
                    NotificationRule.is_active == True,
                    PushSubscription.is_active == True,
                    (NotificationRule.camera_id == camera_id) |
                    (NotificationRule.camera_id == None),
                )
            )
            rows = result.all()

        for rule, sub in rows:
            # Respect per-rule thresholds
            threshold_ok = (
                level == "offline"
                or (level == "critical" and pct >= rule.crit_threshold * 100)
                or (level == "warning"  and pct >= rule.warn_threshold * 100)
            )
            if not threshold_ok:
                continue
            if level == "offline" and not rule.notify_offline:
                continue

            # Fire in a thread pool so we don't block the event loop
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None, send_push, sub.endpoint, sub.p256dh, sub.auth, payload
            )
            logger.info("Push sent | level=%s camera=%s endpoint=...%s", level, camera_id, sub.endpoint[-20:])

    except Exception as exc:
        logger.error("alert_watcher push error: %s", exc)


async def _watch_loop() -> None:
    """Poll loop — runs forever in the background."""
    while True:
        try:
            from backend.database.connection import AsyncSessionLocal
            from backend.database.models import Camera

            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    select(Camera).where(Camera.is_active == True)
                )
                cameras = result.scalars().all()

            for cam in cameras:
                cid   = cam.camera_id
                zname = cam.zone_name or cam.name
                cap   = cam.zone_capacity or 0

                state = _zone_states.setdefault(cid, _ZoneState())
                live  = _get_live_count(cid)

                if live is None:
                    # Camera went offline
                    if state.was_running:
                        state.was_running     = False
                        state.last_warn_fired = False
                        state.last_crit_fired = False
                        asyncio.create_task(_fire_push_for_zone(cid, zname, 0, cap, 0.0, "offline"))
                    continue

                current, _, _ = live
                state.was_running = True
                pct = (current / cap * 100) if cap > 0 else 0.0

                # Critical crossing
                if pct >= 90.0 and not state.last_crit_fired:
                    state.last_crit_fired = True
                    asyncio.create_task(_fire_push_for_zone(cid, zname, current, cap, pct, "critical"))
                elif pct < 85.0:  # reset so next crossing fires again
                    state.last_crit_fired = False

                # Warning crossing (only if not already critical)
                if pct >= 80.0 and pct < 90.0 and not state.last_warn_fired:
                    state.last_warn_fired = True
                    asyncio.create_task(_fire_push_for_zone(cid, zname, current, cap, pct, "warning"))
                elif pct < 75.0:
                    state.last_warn_fired = False

        except asyncio.CancelledError:
            return
        except Exception as exc:
            logger.error("alert_watcher loop error: %s", exc)

        await asyncio.sleep(POLL_INTERVAL)


def start_alert_watcher() -> asyncio.Task:
    task = asyncio.create_task(_watch_loop())
    logger.info("Alert watcher started (poll every %ds)", POLL_INTERVAL)
    return task


# ---------------------------------------------------------------------------
# Demo alert simulator — fires fake pushes from demo camera data
# ---------------------------------------------------------------------------

DEMO_CAMERAS = [
    {"camera_id": "demo-main",     "zone_name": "Main Floor",       "capacity": 91},
    {"camera_id": "demo-balcony",  "zone_name": "Balcony",          "capacity": 60},
    {"camera_id": "demo-overflow", "zone_name": "Overflow Room",    "capacity": 50},
    {"camera_id": "demo-stadium",  "zone_name": "Stadium — Main Bowl", "capacity": 10000},
]

async def fire_demo_alerts() -> int:
    """
    Fires a sequence of realistic demo push notifications across the demo cameras.
    Returns the count of pushes fired.
    Designed to prove the full notification pipeline works without a real camera.
    """
    import random

    scenarios = [
        # (camera_idx, level, pct_override)
        (0, "warning",  82.0),   # Main Floor filling up
        (1, "critical", 93.0),   # Balcony overcrowded
        (2, "warning",  80.0),   # Overflow filling up
        (0, "critical", 91.0),   # Main Floor overcrowded
        (3, "warning",  81.0),   # Stadium filling up
    ]

    fired = 0
    for cam_idx, level, pct in scenarios:
        cam = DEMO_CAMERAS[cam_idx]
        current = int(cam["capacity"] * pct / 100)
        await _fire_push_for_zone(
            camera_id = cam["camera_id"],
            zone_name = cam["zone_name"],
            current   = current,
            capacity  = cam["capacity"],
            pct       = pct,
            level     = level,
        )
        fired += 1
        await asyncio.sleep(1.5)   # stagger so notifications don't collapse

    # Also fire a demo AI review request notification
    await _fire_review_push_demo()
    fired += 1

    logger.info("Demo alerts fired: %d", fired)
    return fired


async def _fire_review_push_demo() -> None:
    """Fire a demo push for an AI review question."""
    try:
        from backend.database.connection import AsyncSessionLocal
        from backend.database.push_models import PushSubscription, NotificationRule
        from backend.database.models import User
        from backend.services.push_sender import send_push
        from sqlalchemy import select

        payload = {
            "title":     "🎭 Kyro question — demo-main",
            "body":      "Someone moved toward the front — is this the stage or altar area? · Seat C5 (low confidence)",
            "tag":       "kyro-review-demo-1",
            "camera_id": "demo-main",
            "level":     "review",
        }

        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(NotificationRule, PushSubscription)
                .join(PushSubscription, NotificationRule.subscription_id == PushSubscription.id)
                .where(
                    NotificationRule.is_active == True,
                    PushSubscription.is_active == True,
                )
            )
            rows = result.all()

        loop = asyncio.get_event_loop()
        for rule, sub in rows:
            await loop.run_in_executor(None, send_push, sub.endpoint, sub.p256dh, sub.auth, payload)
            logger.info("Demo review push sent endpoint=...%s", sub.endpoint[-20:])

    except Exception as exc:
        logger.error("Demo review push error: %s", exc)
