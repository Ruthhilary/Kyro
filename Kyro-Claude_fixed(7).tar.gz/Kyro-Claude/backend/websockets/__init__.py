# WebSocket connection manager
