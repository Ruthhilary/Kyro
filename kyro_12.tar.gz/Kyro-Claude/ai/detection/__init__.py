# Person detection module
