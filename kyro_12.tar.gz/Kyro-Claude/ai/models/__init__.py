# Model weight management
